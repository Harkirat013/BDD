# WiniumSample

Winium sample project - Opens windows notepad paste some text, exits notepad without saving it. 
